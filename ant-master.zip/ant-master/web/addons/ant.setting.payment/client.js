//
//  6.1儿童节快乐 :)
//  虽然早已长大
//

;(function($, undefined) {
    var layout = {
        name: 'setting_payment_layout',
        panels: [{
            type: 'main',
            content: '<div id="setting_payment_tabs" style="width:100%;"></div><div id="setting_payment_selected" style="padding:10px;">test</div>',
            tabs: {
                tabs: [
                    { id: 'mail', caption: '<i class="fa fa-wechat"></i> 支付' },
                ],
                onClick: function(event) {
                    var html = '';
                    switch(event.target) {
                        case 'mail':
                            html = '<h3>联系邮箱</h3>' + 
                                '<h3>seczz#qq.com;#替换为at</h3>'
                            break;
                        case 'about':
                        default:
                            html = '<h4>联系邮箱</h4>' 
                    }
                    $('#setting_payment_selected').html(html);
                }
            }
        }],
        onRender: function(event) {
            event.onComplete = function() {
                w2ui['setting_payment_layout_main_tabs'].click('about');
            }
        }
    }
    $().w2layout(layout);

    w2ui['sidebar'].add('ant_setting', {
        id: 'setting_payment',
        text: 'S币充值',
        icon: 'fa fa-money',
        onClick: function() {
            w2ui['layout'].content('main', w2ui['setting_payment_layout']);
        }
    })
})(jQuery)