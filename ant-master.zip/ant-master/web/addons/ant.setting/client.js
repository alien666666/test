;(function($, undefined) {
	var ADDON = {
		init: function() {}
	};
	ANT.initAddon({
		id: 'ant_setting',
		text: '系统设置',
		group: true,
		expanded: true,
		nodes: []
	}, ADDON)
})(jQuery)